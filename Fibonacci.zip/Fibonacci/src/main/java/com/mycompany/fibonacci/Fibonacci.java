/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fibonacci;
import java.util.Scanner;
/**
 *
 * @author Lenovo-User
 */
public class Fibonacci {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of terms: ");
        int numTerms = scanner.nextInt();

        System.out.println("Fibonacci series up to " + numTerms + " terms:");
        printFibonacci(numTerms);
    }

    // Function to print Fibonacci series up to n terms
    public static void printFibonacci(int numTerms) {
        int firstTerm = 0, secondTerm = 1;

        if (numTerms >= 1) {
            System.out.print(firstTerm + " ");
        }
        if (numTerms >= 2) {
            System.out.print(secondTerm + " ");
        }

        for (int i = 3; i <= numTerms; i++) {
            int nextTerm = firstTerm + secondTerm;
            System.out.print(nextTerm + " ");
            firstTerm = secondTerm;
            secondTerm = nextTerm;
        }
    }
}
    

